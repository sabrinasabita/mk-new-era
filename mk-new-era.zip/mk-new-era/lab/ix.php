<html>
<head>
	<link rel="stylesheet" href="ix.css">
	<style>
	</style>
</head>
<body>
<header>
  <h1>Plugin to Get JSON Structure with AJAX</h1>
  <button id="btn" class="bmain">Fetch Info for New Users</button>
</header>

<div id="user-info">
</div>

<script type="text/javascript" src="ix.js"></script>

</body>
</html>