var pageCounter = 1;
var userContainer = document.getElementById("user-info");
var btn = document.getElementById("btn");

  btn.addEventListener("click", function() {
  var ourRequest = new XMLHttpRequest();
  ourRequest.open('GET', 'https://jsonplaceholder.typicode.com/users/');
  ourRequest.onload = function() {
    if (ourRequest.status >= 200 && ourRequest.status < 400) {
	  console.log(ourRequest.responseText);
      var ourData = JSON.parse(ourRequest.responseText);
	  console.log(ourData);
      renderHTML(ourData);
	  xload()
    } else {
      if (ourRequest.status <= 200) {
        console.log("We connected to the server, but the JSON Source Doesn't Exists.");
      } else {
        console.log("We connected to the server, but it returned an error.");
	  }
    }
	
    
  };
  
  ourRequest.onerror = function() {
    console.log("Connection error");
  };

  ourRequest.send();
  pageCounter++;

  if (pageCounter > 1) {
    btn.classList.add("hide-me");
  }
});

function renderHTML(data) {

  var htmlString = "";
  console.log("longitud: " + data.length);
  htmlString = "<h2></h2>\n";
  htmlString += "<table class=\"usertable\">\n";
  htmlString += "<thead>\n<tr>\n<th>NAME</th>\n<th>USER NAME</th>\n<th>ID</th>\n</tr></thead><tbody>\n";
  for (i = 0; i < data.length; i++) {
    htmlString += "<tr onclick=\"myFunction" + i + "()\" id=\"trow\" class=\"xrow" + i + "\">\n" + "<td>" + "<button class=\"detail\" onclick=\"\">" + data[i].name + "</button>" + "</td>\n<td>" + data[i].username + "\n</td>" + "<td>" + data[i].id + "</td>\n" + "</tr>";
    htmlString += "<tr width=\"100%\" id=\"ddrow" + i + "\" class=\"drow\">" + "<td colspan=\"4\">\n<div id=\"udetail" + i + "\">\n<p>" + data[i].email + "<br>" + data[i].address.street + "\, " + data[i].address.suite + "\, " + data[i].address.city + "\, " + data[i].address.zipcode + "\." + "</p></div>\n" + "</td>\n" + "</tr>\n";
    }
  htmlString += '</tbody>';
  htmlString += '<tfoot><tr><td colspan=\"4\"><div class=\"links\"><a id="husers" class=\"active\" href=\"\" >Thanks for Try It.</a></div>\n</td>\n</tr>\n</tfoot>\n';
  htmlString += '</table>';


  userContainer.insertAdjacentHTML('beforeend', htmlString);

}

function resetTagp() {
    
    if (document.getElementById("ddrow0").style.display === "inline") {
        document.getElementById("ddrow0").style.display = "none";
		document.getElementById("ddrow0").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow1").style.display === "inline") {
        document.getElementById("ddrow1").style.display = "none";
		document.getElementById("ddrow1").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow2").style.display === "inline") {
        document.getElementById("ddrow2").style.display = "none";
		document.getElementById("ddrow2").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow3").style.display === "inline") {
        document.getElementById("ddrow3").style.display = "none";
		document.getElementById("ddrow3").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow4").style.display === "inline") {
        document.getElementById("ddrow4").style.display = "none";
		document.getElementById("ddrow4").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow5").style.display === "inline") {
        document.getElementById("ddrow5").style.display = "none";
		document.getElementById("ddrow5").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow6").style.display === "inline") {
        document.getElementById("ddrow6").style.display = "none";
		document.getElementById("ddrow6").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow7").style.display === "inline") {
        document.getElementById("ddrow7").style.display = "none";
		document.getElementById("ddrow7").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow8").style.display === "inline") {
        document.getElementById("ddrow8").style.display = "none";
		document.getElementById("ddrow8").style.visibility = "hidden";
    }
    if (document.getElementById("ddrow9").style.display === "inline") {
        document.getElementById("ddrow9").style.display = "none";
		document.getElementById("ddrow9").style.visibility = "hidden";
    }
}

function myFunction0() {
    resetTagp();
    document.getElementById("ddrow0").style.display = "inline";
	document.getElementById("ddrow0").style.opacity = "100";
	document.getElementById("ddrow0").style.visibility = "visible";
}
function myFunction1() {
    resetTagp();
    document.getElementById("ddrow1").style.display = "inline";
	document.getElementById("ddrow1").style.opacity = "100";
	document.getElementById("ddrow1").style.visibility = "visible";
}
function myFunction2() {
    resetTagp();
    document.getElementById("ddrow2").style.display = "inline";
	document.getElementById("ddrow2").style.opacity = "100";
	document.getElementById("ddrow2").style.visibility = "visible";
}
function myFunction3() {
    resetTagp();
    document.getElementById("ddrow3").style.display = "inline";
	document.getElementById("ddrow3").style.opacity = "100";
	document.getElementById("ddrow3").style.visibility = "visible";
}
function myFunction4() {
    resetTagp();
    document.getElementById("ddrow4").style.display = "inline";
	document.getElementById("ddrow4").style.opacity = "100";
	document.getElementById("ddrow4").style.visibility = "visible";
}
function myFunction5() {
    resetTagp();
    document.getElementById("ddrow5").style.display = "inline";
	document.getElementById("ddrow5").style.opacity = "100";
	document.getElementById("ddrow5").style.visibility = "visible";
}
function myFunction6() {
    resetTagp();
    document.getElementById("ddrow6").style.display = "inline";
	document.getElementById("ddrow6").style.opacity = "100";
	document.getElementById("ddrow6").style.visibility = "visible";
}
function myFunction7() {
    resetTagp();
    document.getElementById("ddrow7").style.display = "inline";
	document.getElementById("ddrow7").style.opacity = "100";
	document.getElementById("ddrow7").style.visibility = "visible";
}
function myFunction8() {
    resetTagp();
    document.getElementById("ddrow8").style.display = "inline";
	document.getElementById("ddrow8").style.opacity = "100";
	document.getElementById("ddrow8").style.visibility = "visible";
}
function myFunction9() {
    resetTagp();
    document.getElementById("ddrow9").style.display = "inline";
	document.getElementById("ddrow9").style.opacity = "100";
	document.getElementById("ddrow9").style.visibility = "visible";
}

function xload() {
    console.log("Pase la carga")
		document.getElementById("ddrow0").style.display = "none";
		document.getElementById("ddrow0").style.visibility = "hidden";
        document.getElementById("ddrow1").style.display = "none";
		document.getElementById("ddrow1").style.visibility = "hidden";
        document.getElementById("ddrow2").style.display = "none";
		document.getElementById("ddrow2").style.visibility = "hidden";
        document.getElementById("ddrow3").style.display = "none";
		document.getElementById("ddrow3").style.visibility = "hidden";
        document.getElementById("ddrow4").style.display = "none";
		document.getElementById("ddrow4").style.visibility = "hidden";
        document.getElementById("ddrow5").style.display = "none";
		document.getElementById("ddrow5").style.visibility = "hidden";
        document.getElementById("ddrow6").style.display = "none";
		document.getElementById("ddrow6").style.visibility = "hidden";
        document.getElementById("ddrow7").style.display = "none";
		document.getElementById("ddrow7").style.visibility = "hidden";
        document.getElementById("ddrow8").style.display = "none";
		document.getElementById("ddrow8").style.visibility = "hidden";
        document.getElementById("ddrow9").style.display = "none";
		document.getElementById("ddrow9").style.visibility = "hidden";
}
